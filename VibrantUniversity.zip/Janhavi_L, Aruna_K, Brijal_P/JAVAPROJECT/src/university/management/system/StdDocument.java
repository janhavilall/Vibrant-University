package university.management.system;

public class StdDocument {
    public static void main(String[] args) {
        new StdDocument();
        System.out.println("Student document page");

    }
}
